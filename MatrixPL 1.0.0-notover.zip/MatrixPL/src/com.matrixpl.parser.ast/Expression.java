package com.matrixpl.parser.ast;

public interface Expression {
    double eval();
}
