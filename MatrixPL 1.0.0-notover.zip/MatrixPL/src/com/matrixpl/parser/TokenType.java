package com.matrixpl.parser;

public enum TokenType {
    STAR,
    SLASH,
    PLUS,
    MINUS,

    NUMBER,

    EOF
}
