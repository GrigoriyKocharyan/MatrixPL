package com.matrixpl.parser;

import com.matrixpl.parser.ast.Expression;

import java.util.List;

public final class Parser {
    private List<Token> tokens;
    private int pos;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    public List<Expression> parse() {
        return null;
    }

    private char peek(int relativePosition) {
        final int position = pos + relativePosition;
        if (position >= length) return '\0';
        return  input.charAt(position);
    }
}
